<?php
// Run locally/CLI only: php setup-password.php 'your-strong-password'
// Delete this file from public hosting after use.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
$password=$argv[1]??'';
if(strlen($password)<12){fwrite(STDERR,"Use at least 12 characters.\n");exit(1);}
echo password_hash($password,PASSWORD_DEFAULT),PHP_EOL;