<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') redirect('dashboard.php');
verify_csrf();
unset($_SESSION['admin'], $_SESSION['last_result']);
session_regenerate_id(true);
redirect('login.php');
