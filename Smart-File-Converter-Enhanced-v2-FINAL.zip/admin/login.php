<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
if (!empty($_SESSION['admin'])) redirect('dashboard.php');
$error = '';
$rate = login_rate_status();
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    verify_csrf();
    $rate = login_rate_status();
    if (!$rate['allowed']) {
        $error = 'Too many failed attempts. Please wait 15 minutes before trying again.';
    } else {
        $hash = (string)config('ADMIN_PASSWORD_HASH');
        $usernameOk = hash_equals((string)config('ADMIN_USERNAME'), (string)($_POST['username'] ?? ''));
        $passwordOk = $hash !== '' && password_verify((string)($_POST['password'] ?? ''), $hash);
        if ($usernameOk && $passwordOk) {
            clear_login_failures();
            session_regenerate_id(true);
            $_SESSION['admin'] = true;
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            redirect('dashboard.php');
        }
        record_login_failure();
        $error = $hash === '' ? 'Admin login is not configured on the server yet.' : 'Login failed. Check credentials.';
    }
}
$pageTitle = 'Admin Login';
include dirname(__DIR__) . '/includes/header.php';
?>
<main class="container narrow"><section class="upload-panel"><h1>Admin Login</h1><?php if ($error): ?><p class="alert error"><?=e($error)?></p><?php endif; ?><form method="post"><?=csrf_field()?><label>Username<input name="username" required autocomplete="username"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button class="btn primary" type="submit" <?=!$rate['allowed']?'disabled':''?>>Login</button></form><p class="small muted">Configure SFC_ADMIN_USER and SFC_ADMIN_PASSWORD_HASH in hosting environment before use.</p></section></main>
<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
