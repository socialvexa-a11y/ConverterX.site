<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
if (empty($_SESSION['admin'])) redirect('login.php');
$toolLabels = [
    'image_compress' => 'Image Compress',
    'image_convert' => 'Image Format Convert',
    'image_resize' => 'Image Resize',
    'zip_create' => 'Create ZIP',
    'zip_extract' => 'Extract / Repack ZIP',
    'pdf_compress' => 'PDF Compress',
    'pdf_merge' => 'Merge PDF',
    'office_pdf' => 'Office to PDF',
];
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    verify_csrf();
    if (($_POST['action'] ?? '') === 'save_settings') {
        $ok = save_app_settings([
            'maintenance_mode' => isset($_POST['maintenance_mode']),
            'max_upload_mb' => (int)($_POST['max_upload_mb'] ?? config('MAX_UPLOAD_MB')),
            'announcement' => (string)($_POST['announcement'] ?? ''),
            'tools' => $_POST['tools'] ?? [],
        ]);
        flash($ok ? 'Settings saved successfully.' : 'Could not save settings. Check storage folder permissions.', $ok ? 'info' : 'error');
        redirect('dashboard.php');
    }
}
$settings = app_settings();
$counts = [
    'uploads' => count(glob(SFC_STORAGE . '/uploads/*') ?: []),
    'processed' => count(glob(SFC_STORAGE . '/processed/*') ?: []),
];
$bytes = 0;
foreach (array_merge(glob(SFC_STORAGE . '/uploads/*') ?: [], glob(SFC_STORAGE . '/processed/*') ?: []) as $f) {
    if (is_file($f)) $bytes += (int)filesize($f);
}
$pageTitle = 'Admin Dashboard';
include dirname(__DIR__) . '/includes/header.php';
?>
<main class="container">
 <section class="page-title"><h1>Admin Dashboard</h1><p class="muted">Manage processing tools, maintenance mode and upload limits.</p></section>
 <div class="cards">
  <article class="card"><h3>Temporary uploads</h3><strong class="metric"><?=$counts['uploads']?></strong></article>
  <article class="card"><h3>Processed files</h3><strong class="metric"><?=$counts['processed']?></strong></article>
  <article class="card"><h3>Storage in use</h3><strong class="metric"><?=number_format($bytes / 1048576, 2)?> MB</strong></article>
  <article class="card"><h3>Retention period</h3><strong class="metric"><?= (int)config('RETENTION_MINUTES') ?> min</strong></article>
 </div>
 <section class="upload-panel">
  <h2>Website Settings</h2>
  <form method="post" class="admin-settings-form">
   <?=csrf_field()?>
   <input type="hidden" name="action" value="save_settings">
   <label class="check-row"><input type="checkbox" name="maintenance_mode" value="1" <?=$settings['maintenance_mode']?'checked':''?>> Enable Maintenance Mode (visitors will see a maintenance message)</label>
   <label>Maximum upload size per file (MB)<input type="number" name="max_upload_mb" min="1" max="<?= (int)config('MAX_UPLOAD_MB') ?>" value="<?= (int)$settings['max_upload_mb'] ?>" required></label>
   <label>Announcement on homepage (optional)<input type="text" name="announcement" maxlength="240" value="<?=e($settings['announcement'])?>" placeholder="Write a short notice for visitors"></label>
   <h3>Tool Management</h3>
   <div class="tool-toggle-grid">
   <?php foreach ($toolLabels as $key => $label): ?><label class="check-row"><input type="checkbox" name="tools[<?=e($key)?>]" value="1" <?=!empty($settings['tools'][$key])?'checked':''?>> <?=e($label)?></label><?php endforeach; ?>
   </div>
   <button class="btn primary" type="submit">Save Settings</button>
  </form>
 </section>
 <section class="upload-panel"><h2>Server Capabilities</h2><ul>
  <li>PHP version: <?=e(PHP_VERSION)?></li>
  <li>PHP GD: <?=extension_loaded('gd')?'Available':'Not available'?></li>
  <li>PHP ZipArchive: <?=class_exists('ZipArchive')?'Available':'Not available'?></li>
  <li>Fileinfo: <?=extension_loaded('fileinfo')?'Available':'Not available'?></li>
  <li>Ghostscript: <?=tool_available('gs')?'Available':'Not available'?></li>
  <li>qpdf: <?=tool_available('qpdf')?'Available':'Not available'?></li>
  <li>LibreOffice: <?=tool_available('libreoffice')?'Available':'Not available'?></li>
 </ul>
 <form method="post" action="logout.php" class="logout-form"><?=csrf_field()?><button class="btn secondary" type="submit">Logout</button></form>
 </section>
</main>
<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
