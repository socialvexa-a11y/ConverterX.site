<?php
require __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'All Tools - ' . config('APP_NAME');
$category = strtolower((string)($_GET['category'] ?? 'all'));
$items = [
 ['Image Compress','image_compress','image','PHP GD required'],
 ['Image Format Convert','image_convert','image','PHP GD required'],
 ['Image Resize','image_resize','image','PHP GD required'],
 ['Create ZIP','zip_create','zip','PHP ZipArchive required'],
 ['Extract / Repack ZIP','zip_extract','zip','PHP ZipArchive required'],
 ['PDF Compress','pdf_compress','pdf','Ghostscript required'],
 ['Merge PDF','pdf_merge','pdf','qpdf required'],
 ['DOCX / XLSX / PPTX to PDF','office_pdf','office','LibreOffice required'],
];
include __DIR__ . '/includes/header.php';
?>
<main class="container"><section class="page-title"><h1>All file tools</h1><p class="muted">Select a tool, upload your file and download the result.</p></section>
<div class="cards">
<?php $shown = 0; foreach ($items as $it): if ($category !== 'all' && $category !== $it[2]) continue; if (!tool_is_enabled($it[1])) continue; $shown++; ?>
<article class="card"><div class="tool-icon"><i class="fa-solid fa-file-arrow-up"></i></div><h3><?=e($it[0])?></h3><p><?=e($it[3])?></p><a class="text-link" href="index.php#tools">Use this tool →</a></article>
<?php endforeach; ?>
</div>
<?php if ($shown === 0): ?><p class="alert">No enabled tools found in this category.</p><?php endif; ?>
<p class="small muted">PDF and Office operations work only when the required software is installed and enabled by your hosting provider. PDF to JPG, OCR and other unlisted operations are not included in this build.</p>
</main><?php include __DIR__ . '/includes/footer.php'; ?>
