<?php $footerPrefix = str_contains(str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '')), '/admin/') ? '../' : ''; ?>
<footer class="footer"><div>© <?=date('Y')?> Smart File Converter</div><div>Files are temporary. Do not upload confidential documents.</div></footer><script src="<?=$footerPrefix?>assets/app.js"></script></body></html>
