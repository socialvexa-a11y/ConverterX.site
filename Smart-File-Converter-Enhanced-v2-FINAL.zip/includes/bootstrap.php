<?php
declare(strict_types=1);
$config = require dirname(__DIR__) . '/config.php';
date_default_timezone_set($config['TIMEZONE'] ?? 'UTC');

if (!defined('SFC_ROOT')) define('SFC_ROOT', dirname(__DIR__));
if (!defined('SFC_STORAGE')) define('SFC_STORAGE', SFC_ROOT . '/storage');

foreach (['uploads', 'processed', 'logs'] as $d) {
    $p = SFC_STORAGE . '/' . $d;
    if (!is_dir($p)) @mkdir($p, 0750, true);
}

$isHttps = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('sfc_session');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
    session_set_cookie_params([
        'httponly' => true,
        'secure' => $isHttps,
        'samesite' => 'Lax',
        'path' => '/',
    ]);
    session_start();
}

// Basic browser security headers. CSP is intentionally not restrictive because the existing UI loads Font Awesome from a CDN.
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

function config(string $key) {
    global $config;
    return $config[$key] ?? null;
}
function e($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function csrf_field(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function verify_csrf(): void {
    $known = (string)($_SESSION['csrf'] ?? '');
    $given = (string)($_POST['csrf'] ?? '');
    if ($known === '' || $given === '' || !hash_equals($known, $given)) {
        http_response_code(419);
        exit('Invalid request token. Please refresh the page and try again.');
    }
}
function flash(string $message, string $type = 'info'): void {
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}
function app_settings(): array {
    static $settings = null;
    if ($settings !== null) return $settings;
    $defaults = [
        'maintenance_mode' => false,
        'max_upload_mb' => (int)config('MAX_UPLOAD_MB'),
        'announcement' => '',
        'tools' => [
            'image_compress' => true,
            'image_convert' => true,
            'image_resize' => true,
            'zip_create' => true,
            'zip_extract' => true,
            'pdf_compress' => true,
            'pdf_merge' => true,
            'office_pdf' => true,
        ],
    ];
    $file = SFC_STORAGE . '/settings.json';
    if (is_file($file)) {
        $saved = json_decode((string)@file_get_contents($file), true);
        if (is_array($saved)) {
            $defaults['maintenance_mode'] = !empty($saved['maintenance_mode']);
            $defaults['max_upload_mb'] = max(1, min((int)config('MAX_UPLOAD_MB'), (int)($saved['max_upload_mb'] ?? $defaults['max_upload_mb'])));
            $announcement = trim((string)($saved['announcement'] ?? ''));
            $defaults['announcement'] = function_exists('mb_substr') ? mb_substr($announcement, 0, 240) : substr($announcement, 0, 240);
            if (isset($saved['tools']) && is_array($saved['tools'])) {
                foreach ($defaults['tools'] as $key => $enabled) {
                    $defaults['tools'][$key] = !empty($saved['tools'][$key]);
                }
            }
        }
    }
    $settings = $defaults;
    return $settings;
}
function save_app_settings(array $newSettings): bool {
    $current = app_settings();
    $current['maintenance_mode'] = !empty($newSettings['maintenance_mode']);
    $current['max_upload_mb'] = max(1, min((int)config('MAX_UPLOAD_MB'), (int)($newSettings['max_upload_mb'] ?? $current['max_upload_mb'])));
    $announcement = trim((string)($newSettings['announcement'] ?? ''));
    $current['announcement'] = function_exists('mb_substr') ? mb_substr($announcement, 0, 240) : substr($announcement, 0, 240);
    $postedTools = is_array($newSettings['tools'] ?? null) ? $newSettings['tools'] : [];
    foreach ($current['tools'] as $key => $enabled) $current['tools'][$key] = !empty($postedTools[$key]);
    $tmp = SFC_STORAGE . '/settings.' . bin2hex(random_bytes(6)) . '.tmp';
    $json = json_encode($current, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json === false || @file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    if (!@rename($tmp, SFC_STORAGE . '/settings.json')) {
        @unlink($tmp);
        return false;
    }
    return true;
}
function max_upload_mb(): int {
    return max(1, min((int)config('MAX_UPLOAD_MB'), (int)(app_settings()['max_upload_mb'] ?? config('MAX_UPLOAD_MB'))));
}
function tool_is_enabled(string $tool): bool {
    $tools = app_settings()['tools'] ?? [];
    return array_key_exists($tool, $tools) && $tools[$tool] === true;
}

function login_rate_status(): array {
    $file = SFC_STORAGE . '/login-attempts.json';
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $key = hash('sha256', $ip . '|' . SFC_ROOT);
    $fp = @fopen($file, 'c+');
    if (!$fp) return ['allowed' => true, 'retry' => 0, 'key' => $key];
    flock($fp, LOCK_EX);
    $raw = stream_get_contents($fp);
    $data = is_string($raw) ? json_decode($raw, true) : [];
    if (!is_array($data)) $data = [];
    $now = time();
    $entry = $data[$key] ?? ['count' => 0, 'first' => $now];
    if (($now - (int)($entry['first'] ?? 0)) > 900) $entry = ['count' => 0, 'first' => $now];
    $allowed = (int)($entry['count'] ?? 0) < 5;
    $retry = $allowed ? 0 : max(1, 900 - ($now - (int)$entry['first']));
    flock($fp, LOCK_UN);
    fclose($fp);
    return ['allowed' => $allowed, 'retry' => $retry, 'key' => $key];
}
function record_login_failure(): void {
    $file = SFC_STORAGE . '/login-attempts.json';
    $status = login_rate_status();
    $fp = @fopen($file, 'c+');
    if (!$fp) return;
    flock($fp, LOCK_EX);
    $raw = stream_get_contents($fp);
    $data = is_string($raw) ? json_decode($raw, true) : [];
    if (!is_array($data)) $data = [];
    $now = time();
    $entry = $data[$status['key']] ?? ['count' => 0, 'first' => $now];
    if (($now - (int)($entry['first'] ?? 0)) > 900) $entry = ['count' => 0, 'first' => $now];
    $entry['count'] = (int)($entry['count'] ?? 0) + 1;
    $entry['last'] = $now;
    $data[$status['key']] = $entry;
    ftruncate($fp, 0); rewind($fp);
    fwrite($fp, json_encode($data)); fflush($fp);
    flock($fp, LOCK_UN); fclose($fp);
}
function clear_login_failures(): void {
    $file = SFC_STORAGE . '/login-attempts.json';
    $status = login_rate_status();
    $fp = @fopen($file, 'c+');
    if (!$fp) return;
    flock($fp, LOCK_EX);
    $raw = stream_get_contents($fp);
    $data = is_string($raw) ? json_decode($raw, true) : [];
    if (!is_array($data)) $data = [];
    unset($data[$status['key']]);
    ftruncate($fp, 0); rewind($fp);
    fwrite($fp, json_encode($data)); fflush($fp);
    flock($fp, LOCK_UN); fclose($fp);
}

function tool_available(string $cmd): bool {
    $allowed = ['gs', 'qpdf', 'libreoffice'];
    if (!in_array($cmd, $allowed, true)) return false;
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    if (in_array('exec', $disabled, true) || !function_exists('exec')) return false;
    $out = [];
    $code = 1;
    @exec('command -v ' . escapeshellarg($cmd) . ' 2>/dev/null', $out, $code);
    return $code === 0 && !empty($out);
}
function clean_old_files(): void {
    $cut = time() - ((int)config('RETENTION_MINUTES') * 60);
    foreach (['uploads', 'processed'] as $dir) {
        foreach (glob(SFC_STORAGE . '/' . $dir . '/*') ?: [] as $f) {
            if (is_file($f) && filemtime($f) < $cut) @unlink($f);
        }
    }
}
function safe_name(string $name): string {
    $name = basename(str_replace('\\', '/', $name));
    $name = preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?? 'file';
    $name = trim($name, '.');
    return $name !== '' ? substr($name, 0, 120) : 'file';
}
function unique_archive_name(string $name, array &$used): string {
    $name = safe_name($name);
    $candidate = $name;
    $n = 1;
    while (isset($used[strtolower($candidate)])) {
        $ext = pathinfo($name, PATHINFO_EXTENSION);
        $base = pathinfo($name, PATHINFO_FILENAME);
        $candidate = $base . '-' . $n++ . ($ext !== '' ? '.' . $ext : '');
    }
    $used[strtolower($candidate)] = true;
    return $candidate;
}
function upload_files(): array {
    if (empty($_FILES['files']) || !isset($_FILES['files']['name']) || !is_array($_FILES['files']['name'])) return [];
    $f = $_FILES['files'];
    $out = [];
    $maxEach = max_upload_mb() * 1024 * 1024;
    $maxTotal = (int)config('MAX_TOTAL_UPLOAD_MB') * 1024 * 1024;
    $total = 0;
    $count = count($f['name']);
    if ($count > (int)config('MAX_FILES_PER_JOB')) throw new RuntimeException('You can upload up to ' . (int)config('MAX_FILES_PER_JOB') . ' files per job.');
    try {
        foreach ($f['name'] as $i => $name) {
            $error = (int)($f['error'][$i] ?? UPLOAD_ERR_NO_FILE);
            if ($error === UPLOAD_ERR_NO_FILE) continue;
            if ($error !== UPLOAD_ERR_OK) throw new RuntimeException('Upload failed for ' . safe_name((string)$name) . '. Check the hosting upload limit.');
            $size = (int)($f['size'][$i] ?? 0);
            if ($size < 1 || $size > $maxEach) throw new RuntimeException('Each file must be between 1 byte and ' . max_upload_mb() . ' MB.');
            $total += $size;
            if ($total > $maxTotal) throw new RuntimeException('Combined upload size must not exceed ' . (int)config('MAX_TOTAL_UPLOAD_MB') . ' MB.');
            $tmp = (string)($f['tmp_name'][$i] ?? '');
            if ($tmp === '' || !is_uploaded_file($tmp)) throw new RuntimeException('Upload verification failed. Please try again.');
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp) ?: 'application/octet-stream';
            $id = bin2hex(random_bytes(16));
            $ext = strtolower(pathinfo(safe_name((string)$name), PATHINFO_EXTENSION));
            $dest = SFC_STORAGE . '/uploads/' . $id . ($ext !== '' ? '.' . $ext : '');
            if (!move_uploaded_file($tmp, $dest)) throw new RuntimeException('Could not store uploaded file. Check storage folder permissions.');
            $out[] = ['path' => $dest, 'name' => safe_name((string)$name), 'mime' => $mime, 'size' => $size];
        }
    } catch (Throwable $e) {
        foreach ($out as $item) @unlink($item['path']);
        throw $e;
    }
    return $out;
}
function result_download(string $path, string $downloadName): never {
    $base = realpath(SFC_STORAGE . '/processed');
    $real = realpath($path);
    if (!$base || !$real || !is_file($real) || !str_starts_with($real, $base . DIRECTORY_SEPARATOR)) {
        http_response_code(404);
        exit('File not found or expired.');
    }
    $name = safe_name($downloadName);
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $name . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('Content-Length: ' . (string)filesize($real));
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    readfile($real);
    exit;
}

clean_old_files();

// Maintenance mode is bypassed only for an authenticated admin and the admin login endpoint.
$script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
$isAdminLogin = str_ends_with($script, '/admin/login.php');
if (PHP_SAPI !== 'cli' && !empty(app_settings()['maintenance_mode']) && empty($_SESSION['admin']) && !$isAdminLogin) {
    http_response_code(503);
    header('Retry-After: 900');
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maintenance</title><body style="font-family:system-ui;max-width:640px;margin:12vh auto;padding:24px;text-align:center"><h1>We will be back soon</h1><p>Smart File Converter is temporarily under maintenance. Please try again later.</p></body></html>';
    exit;
}
