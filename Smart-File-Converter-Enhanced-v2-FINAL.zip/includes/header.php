<?php
$inAdmin = str_contains(str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '')), '/admin/');
$prefix = $inAdmin ? '../' : '';
$notice = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Free online file converter and compressor"><title><?=e($pageTitle ?? config('APP_NAME'))?></title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="<?=$prefix?>assets/style.css"></head><body><header class="topbar"><a class="brand" href="<?=$prefix?>index.php"><span class="brand-mark"><i class="fa-solid fa-arrows-rotate"></i></span> Smart File Converter</a><nav><a href="<?=$prefix?>index.php">Home</a><a href="<?=$prefix?>tools.php">All tools</a><a href="<?=$prefix?>admin/login.php">Admin</a><button id="langToggle" class="nav-btn">हिंदी</button><button id="themeToggle" class="nav-btn" aria-label="Toggle dark mode"><i class="fa-solid fa-moon"></i></button></nav></header>
<?php if (is_array($notice) && !empty($notice['message'])): ?><div class="container notice-wrap"><div class="alert <?=($notice['type'] ?? '') === 'error' ? 'error' : 'announcement'?>" role="status"><?=e($notice['message'])?></div></div><?php endif; ?>
