<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') redirect('index.php');
verify_csrf();
$files = [];
$created = [];
try {
    $op = (string)($_POST['operation'] ?? '');
    $known = ['image_compress', 'image_convert', 'image_resize', 'zip_create', 'zip_extract', 'pdf_compress', 'pdf_merge', 'office_pdf'];
    if (!in_array($op, $known, true)) throw new RuntimeException('Please choose a valid operation.');
    if (!tool_is_enabled($op)) throw new RuntimeException('This tool is temporarily disabled by the administrator.');
    $files = upload_files();
    if (!$files) throw new RuntimeException('Please select at least one file.');

    $outDir = SFC_STORAGE . '/processed';
    $result = null;
    $download = 'converted-file';

    if (in_array($op, ['image_compress', 'image_convert', 'image_resize'], true)) {
        if (!extension_loaded('gd')) throw new RuntimeException('Image processing requires the PHP GD extension. Enable GD in hosting PHP extensions.');
        $made = [];
        foreach ($files as $f) {
            $imagePath = process_image($f, $op);
            $made[] = $imagePath;
            $created[] = $imagePath;
        }
        if (count($made) > 1) {
            if (!class_exists('ZipArchive')) throw new RuntimeException('PHP ZipArchive is required to download multiple processed images together.');
            $result = $outDir . '/' . bin2hex(random_bytes(16)) . '.zip';
            $zip = new ZipArchive();
            if ($zip->open($result, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new RuntimeException('Could not create the image output ZIP.');
            $used = [];
            foreach ($made as $i => $path) {
                $name = pathinfo($files[$i]['name'], PATHINFO_FILENAME) . '-processed.' . pathinfo($path, PATHINFO_EXTENSION);
                $zip->addFile($path, unique_archive_name($name, $used));
            }
            if (!$zip->close()) throw new RuntimeException('Could not finish the image output ZIP.');
            $download = 'processed-images.zip';
            foreach ($made as $path) @unlink($path);
        } else {
            $result = $made[0];
            $download = pathinfo($files[0]['name'], PATHINFO_FILENAME) . '-processed.' . pathinfo($result, PATHINFO_EXTENSION);
        }
    } elseif ($op === 'zip_create') {
        if (!class_exists('ZipArchive')) throw new RuntimeException('PHP ZipArchive extension is not enabled.');
        $result = $outDir . '/' . bin2hex(random_bytes(16)) . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($result, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new RuntimeException('ZIP creation failed.');
        $used = [];
        foreach ($files as $f) $zip->addFile($f['path'], unique_archive_name($f['name'], $used));
        if (!$zip->close()) throw new RuntimeException('Could not finish creating the ZIP file.');
        $download = 'files.zip';
    } elseif ($op === 'zip_extract') {
        if (count($files) !== 1) throw new RuntimeException('Select exactly one ZIP file.');
        if (!class_exists('ZipArchive')) throw new RuntimeException('PHP ZipArchive extension is not enabled.');
        if (!is_zip_file($files[0]['path'])) throw new RuntimeException('The uploaded file is not a valid ZIP archive.');
        $zip = new ZipArchive();
        if ($zip->open($files[0]['path']) !== true) throw new RuntimeException('Invalid ZIP archive.');
        $maxFiles = (int)config('MAX_ZIP_FILES');
        if ($zip->numFiles > $maxFiles) { $zip->close(); throw new RuntimeException('Archive contains too many entries (limit ' . $maxFiles . ').'); }
        $maxBytes = (int)config('MAX_ZIP_UNCOMPRESSED_MB') * 1024 * 1024;
        $total = 0;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if (!$stat || str_ends_with((string)$stat['name'], '/')) continue;
            $size = (int)($stat['size'] ?? 0);
            if ($size < 0 || $size > $maxBytes || ($total + $size) > $maxBytes) { $zip->close(); throw new RuntimeException('Archive expands beyond the allowed ' . (int)config('MAX_ZIP_UNCOMPRESSED_MB') . ' MB limit.'); }
            $total += $size;
        }
        $result = $outDir . '/' . bin2hex(random_bytes(16)) . '.zip';
        $out = new ZipArchive();
        if ($out->open($result, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { $zip->close(); throw new RuntimeException('Could not create the extracted-files ZIP.'); }
        $used = [];
        $added = 0;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if (!$stat) continue;
            $rawName = str_replace('\\', '/', (string)$stat['name']);
            if ($rawName === '' || str_starts_with($rawName, '/') || preg_match('/(^|\/)\.\.(\/|$)/', $rawName) || str_contains($rawName, "\0") || str_ends_with($rawName, '/')) continue;
            $data = $zip->getFromIndex($i);
            if ($data === false) continue; // encrypted or unreadable entries are skipped
            $entryName = unique_archive_name(basename($rawName), $used);
            if ($out->addFromString($entryName, $data)) $added++;
        }
        $zip->close();
        if (!$out->close()) throw new RuntimeException('Could not finish the extracted-files ZIP.');
        if ($added === 0) { @unlink($result); throw new RuntimeException('No safe, readable files were found in this archive.'); }
        $download = 'extracted-files.zip';
    } elseif ($op === 'pdf_compress') {
        if (count($files) !== 1 || !is_pdf_file($files[0]['path'])) throw new RuntimeException('Select exactly one valid PDF file.');
        if (!tool_available('gs')) throw new RuntimeException('PDF compression requires Ghostscript (gs), which may not be available on shared hosting.');
        $result = $outDir . '/' . bin2hex(random_bytes(16)) . '.pdf';
        $cmd = 'gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/ebook -dNOPAUSE -dQUIET -dBATCH -sOutputFile=' . escapeshellarg($result) . ' ' . escapeshellarg($files[0]['path']) . ' 2>&1';
        $o = []; $rc = 1; @exec($cmd, $o, $rc);
        if ($rc !== 0 || !is_file($result) || filesize($result) < 1) throw new RuntimeException('Ghostscript could not process this PDF.');
        $download = 'compressed.pdf';
    } elseif ($op === 'pdf_merge') {
        if (count($files) < 2) throw new RuntimeException('Select at least two PDF files to merge.');
        foreach ($files as $f) if (!is_pdf_file($f['path'])) throw new RuntimeException('Only valid PDF files can be merged.');
        if (!tool_available('qpdf')) throw new RuntimeException('PDF merge requires qpdf, which is not normally installed on basic shared hosting.');
        $result = $outDir . '/' . bin2hex(random_bytes(16)) . '.pdf';
        $parts = [];
        foreach ($files as $f) $parts[] = escapeshellarg($f['path']) . ' 1-z';
        $cmd = 'qpdf --empty --pages ' . implode(' ', $parts) . ' -- ' . escapeshellarg($result) . ' 2>&1';
        $o = []; $rc = 1; @exec($cmd, $o, $rc);
        if ($rc !== 0 || !is_file($result) || filesize($result) < 1) throw new RuntimeException('qpdf could not merge these PDFs.');
        $download = 'merged.pdf';
    } elseif ($op === 'office_pdf') {
        if (count($files) !== 1) throw new RuntimeException('Select exactly one Office document.');
        $ext = strtolower(pathinfo($files[0]['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['docx', 'xlsx', 'pptx'], true)) throw new RuntimeException('Only DOCX, XLSX or PPTX files are accepted for this conversion.');
        if (!tool_available('libreoffice')) throw new RuntimeException('Office conversion requires LibreOffice installed on the server.');
        $cmd = 'libreoffice --headless --convert-to pdf --outdir ' . escapeshellarg($outDir) . ' ' . escapeshellarg($files[0]['path']) . ' 2>&1';
        $o = []; $rc = 1; @exec($cmd, $o, $rc);
        $candidate = $outDir . '/' . pathinfo($files[0]['path'], PATHINFO_FILENAME) . '.pdf';
        if ($rc !== 0 || !is_file($candidate) || filesize($candidate) < 1) throw new RuntimeException('LibreOffice conversion failed.');
        $result = $candidate;
        $download = pathinfo($files[0]['name'], PATHINFO_FILENAME) . '.pdf';
    }

    if (!$result || !is_file($result) || filesize($result) < 1) throw new RuntimeException('Processing did not produce an output file.');
    $_SESSION['last_result'] = [
        'path' => basename($result),
        'name' => safe_name($download),
        'size' => (int)filesize($result),
        'original' => array_sum(array_column($files, 'size')),
        'created' => time(),
    ];
    foreach ($files as $f) @unlink($f['path']);
    redirect('result.php');
} catch (Throwable $ex) {
    foreach ($files as $f) if (isset($f['path'])) @unlink($f['path']);
    foreach ($created as $path) if (is_string($path) && is_file($path)) @unlink($path);
    if (isset($result) && is_string($result) && is_file($result)) @unlink($result);
    flash($ex->getMessage(), 'error');
    redirect('index.php#tools');
}

function is_zip_file(string $path): bool {
    $fp = @fopen($path, 'rb');
    if (!$fp) return false;
    $sig = fread($fp, 4); fclose($fp);
    return in_array($sig, ["PK\x03\x04", "PK\x05\x06", "PK\x07\x08"], true);
}
function is_pdf_file(string $path): bool {
    $fp = @fopen($path, 'rb');
    if (!$fp) return false;
    $sig = fread($fp, 5); fclose($fp);
    return $sig === '%PDF-';
}
function process_image(array $f, string $op): string {
    $info = @getimagesize($f['path']);
    if (!$info || empty($info[0]) || empty($info[1])) throw new RuntimeException('Uploaded file is not a valid supported image.');
    $width = (int)$info[0]; $height = (int)$info[1];
    if ($width * $height > (int)config('MAX_IMAGE_PIXELS')) throw new RuntimeException('Image dimensions are too large. Maximum allowed is 12 megapixels.');
    $allowed = [IMAGETYPE_JPEG, IMAGETYPE_PNG];
    if (defined('IMAGETYPE_WEBP')) $allowed[] = IMAGETYPE_WEBP;
    if (!in_array((int)$info[2], $allowed, true)) throw new RuntimeException('Only JPG, PNG and WebP images are supported.');
    $bytes = @file_get_contents($f['path']);
    if ($bytes === false) throw new RuntimeException('Could not read uploaded image.');
    $src = @imagecreatefromstring($bytes);
    unset($bytes);
    if (!$src) throw new RuntimeException('Could not decode this image.');

    if ($op === 'image_resize') {
        $boxW = filter_var($_POST['resize_width'] ?? null, FILTER_VALIDATE_INT);
        $boxH = filter_var($_POST['resize_height'] ?? null, FILTER_VALIDATE_INT);
        if (!$boxW || !$boxH || $boxW < 1 || $boxH < 1 || $boxW > 8000 || $boxH > 8000) {
            imagedestroy($src);
            throw new RuntimeException('For resize, enter width and height between 1 and 8000 pixels.');
        }
        $ratio = min($boxW / $width, $boxH / $height);
        $newW = max(1, (int)round($width * $ratio));
        $newH = max(1, (int)round($height * $ratio));
    } else {
        $newW = $width; $newH = $height;
    }

    $fmt = strtolower((string)($_POST['format'] ?? 'jpg'));
    if (!in_array($fmt, ['jpg', 'png', 'webp'], true)) $fmt = 'jpg';
    if ($fmt === 'webp' && !function_exists('imagewebp')) { imagedestroy($src); throw new RuntimeException('WebP output is not supported by this PHP GD build.'); }
    $quality = max(20, min(95, (int)($_POST['quality'] ?? 75)));
    $dest = imagecreatetruecolor($newW, $newH);
    if (!$dest) { imagedestroy($src); throw new RuntimeException('Could not allocate output image memory.'); }
    if ($fmt === 'png' || $fmt === 'webp') {
        imagealphablending($dest, false);
        imagesavealpha($dest, true);
        $transparent = imagecolorallocatealpha($dest, 0, 0, 0, 127);
        imagefilledrectangle($dest, 0, 0, $newW, $newH, $transparent);
    } else {
        $white = imagecolorallocate($dest, 255, 255, 255);
        imagefilledrectangle($dest, 0, 0, $newW, $newH, $white);
    }
    imagecopyresampled($dest, $src, 0, 0, 0, 0, $newW, $newH, $width, $height);
    $path = SFC_STORAGE . '/processed/' . bin2hex(random_bytes(16)) . '.' . $fmt;
    $ok = false;
    if ($fmt === 'jpg') $ok = imagejpeg($dest, $path, $quality);
    elseif ($fmt === 'png') $ok = imagepng($dest, $path, min(9, (int)round((100 - $quality) * 9 / 80)));
    else $ok = imagewebp($dest, $path, $quality);
    imagedestroy($src); imagedestroy($dest);
    if (!$ok || !is_file($path)) { @unlink($path); throw new RuntimeException('Could not save the converted image.'); }
    return $path;
}
