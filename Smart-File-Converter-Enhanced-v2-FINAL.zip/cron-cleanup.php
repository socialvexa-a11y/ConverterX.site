<?php
declare(strict_types=1);
// Run from cPanel Cron Jobs using PHP CLI. Never expose this as a web endpoint.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("CLI only\n"); }
require __DIR__.'/includes/bootstrap.php';
$cutoff = time() - ((int)config('RETENTION_MINUTES') * 60);
$deleted = 0;
foreach (['uploads','processed'] as $dir) {
    foreach (glob(SFC_STORAGE.'/'.$dir.'/*') ?: [] as $file) {
        if (is_file($file) && filemtime($file) < $cutoff && @unlink($file)) $deleted++;
    }
}
echo "Deleted {$deleted} expired file(s).\n";
