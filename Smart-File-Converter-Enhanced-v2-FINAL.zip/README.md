# Smart File Converter — Enhanced cPanel Package (v2)

This version keeps the existing homepage layout, colors, theme toggle and navigation. It adds backend validation, safer temporary file handling, image resizing, admin settings and hosting guidance.

## Included features

- JPG / PNG / WebP image compression and format conversion (PHP GD required; WebP support depends on the GD build).
- **Image Resize** with aspect ratio preserved and configurable maximum width / height.
- Create ZIP archives from multiple uploaded files.
- Safely repack readable files from a ZIP archive into a fresh ZIP. It does not extract archive paths directly onto the server filesystem.
- PDF compression (requires Ghostscript and enabled `exec()`).
- PDF merge (requires qpdf and enabled `exec()`).
- DOCX / XLSX / PPTX to PDF (requires LibreOffice and enabled `exec()`).
- Admin dashboard with tool ON/OFF switches, maintenance mode, homepage announcement and upload-size setting.
- Admin login throttling, CSRF validation, hardened session cookies and security headers.
- Upload count / total size limits, image pixel limits, ZIP entry count and expanded-size limits.
- Temporary file cleanup on requests plus an optional cPanel cron script.
- Existing frontend design and dark mode retained; resize fields appear only when Image Resize is selected.

## Important limitations

- PDF to JPG, OCR, PDF split/rotate, XLSX to CSV and background removal are not implemented in this package.
- Basic shared hosting often does not provide Ghostscript, qpdf or LibreOffice. The Admin Dashboard reports whether these command-line tools are detected.
- Image processing requires PHP GD. ZIP features require PHP ZipArchive. File validation requires PHP Fileinfo.
- `.user.ini` requests 50 MB per file and 105 MB POST size, but the hosting provider may enforce lower limits.
- This package has not been tested on your specific cPanel server. Run the deployment checklist below before public launch.

## cPanel installation

1. In cPanel **MultiPHP Manager**, select PHP **8.1 or newer** for your domain.
2. In **Select PHP Version / Extensions**, enable `fileinfo`, `gd`, `zip` and preferably `mbstring`.
3. Upload this ZIP into `public_html` (or the domain document root) and extract it there. `index.php` must be directly inside the document root, not inside an extra nested folder.
4. Ensure `storage`, `storage/uploads`, `storage/processed` and `storage/logs` are writable by PHP. Use your host's recommended permissions; do not use `777`.
5. Enable HTTPS and open your domain. Test using non-sensitive sample files.
6. If `.user.ini` changes do not take effect immediately, allow PHP's user-ini cache interval or ask your host to apply the limits.
7. If your host uses Nginx without Apache `.htaccess` compatibility, ask support to deny direct web access to `/storage/` and dotfiles at server level.

## Configure the Admin login

No default admin password is shipped. Configure these server environment variables:

- `SFC_ADMIN_USER`
- `SFC_ADMIN_PASSWORD_HASH` (generated using PHP `password_hash()`)

Generate a hash on a local PHP command line:

```sh
php -r "echo password_hash('Use-A-Unique-Strong-Password', PASSWORD_DEFAULT), PHP_EOL;"
```

Set the resulting hash as `SFC_ADMIN_PASSWORD_HASH` in the hosting environment. Do not store a plain-text password in a public PHP file. If your cPanel plan does not provide environment variables, ask the hosting provider for a secure server-side configuration method before enabling admin access. Without the hash, admin login remains disabled.

## Admin controls

After login, the dashboard allows you to:

- Enable / disable individual tools.
- Enable / disable maintenance mode.
- Change the per-file upload limit (up to the configured package maximum of 50 MB).
- Publish a short homepage announcement.
- View temporary storage usage and server capability checks.

The settings are saved in `storage/settings.json`, which is protected by `storage/.htaccess`. Keep that protection in place.

## Automatic cleanup

The app cleans expired files during normal requests. To clean files even when the site is quiet, create a cPanel Cron Job (for example, every 10 minutes):

```sh
/usr/local/bin/php /home/CPANEL_USERNAME/public_html/cron-cleanup.php
```

Replace the PHP executable path, account name and document-root path with the values shown by your hosting provider. `cron-cleanup.php` is CLI-only and is blocked from direct web access by `.htaccess`.

## Before public launch

- Confirm the site is served over HTTPS.
- Confirm `https://YOUR-DOMAIN/storage/` is denied (403/404), not browsable.
- Confirm `https://YOUR-DOMAIN/config.php` and `https://YOUR-DOMAIN/.user.ini` are not downloadable.
- Test image compression, conversion, resize, ZIP creation and ZIP repacking with harmless sample files.
- Check the PHP upload, memory, execution-time and disk limits imposed by your plan.
- Verify admin login, failed-login throttling, tool switches and maintenance mode.
- Ask the host whether Ghostscript, qpdf, LibreOffice and `exec()` are available before advertising those optional conversions.
- Review your hosting provider's security and retention practices before processing confidential documents.

This package improves the application but does not replace server-level security, backups, malware scanning or a production security review.
