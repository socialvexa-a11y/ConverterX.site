(()=>{
 const root=document.documentElement;
 const saved=localStorage.getItem('sfc-theme');
 if(saved)root.dataset.theme=saved;
 document.getElementById('themeToggle')?.addEventListener('click',()=>{root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';localStorage.setItem('sfc-theme',root.dataset.theme)});
 const lang=localStorage.getItem('sfc-lang')||'en';
 const dict={hi:{free:'100% मुफ्त • कोई Paid API नहीं',hero:'कन्वर्ट करें। कंप्रेस करें। तैयार।',sub:'आपका आसान ऑल-इन-वन फाइल कन्वर्टर। फाइलें अस्थायी हैं और अपने आप डिलीट होती हैं।',explore:'टूल देखें',tools:'टूल चुनें',quick:'फाइल प्रोसेस करें'},en:{}};
 function apply(l){localStorage.setItem('sfc-lang',l);document.documentElement.lang=l;document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.dataset.i18n;if(l==='hi'&&dict.hi[k])el.textContent=dict.hi[k];else if(el.dataset.original)el.textContent=el.dataset.original;else el.dataset.original=el.textContent});const b=document.getElementById('langToggle');if(b)b.textContent=l==='hi'?'English':'हिंदी'}
 document.querySelectorAll('[data-i18n]').forEach(el=>el.dataset.original=el.textContent);
 apply(lang);
 document.getElementById('langToggle')?.addEventListener('click',()=>apply((localStorage.getItem('sfc-lang')||'en')==='en'?'hi':'en'));
 const operation=document.getElementById('operationSelect');
 const resize=document.getElementById('resizeFields');
 const fileInput=document.getElementById('fileInput');
 function updateOperation(){if(resize&&operation)resize.hidden=operation.value!=='image_resize';if(fileInput&&operation)fileInput.multiple=!['zip_extract','pdf_compress','office_pdf'].includes(operation.value);}
 operation?.addEventListener('change',updateOperation);updateOperation();
})();
