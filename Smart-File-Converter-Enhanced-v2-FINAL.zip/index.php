<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Smart File Converter';
$tools = [
    ['PDF Tools', 'file-pdf', 'PDF Compress and Merge (server support required)', 'pdf'],
    ['Image Tools', 'image', 'JPG, PNG, WebP conversion, compression and resizing', 'image'],
    ['ZIP Tools', 'archive', 'Create ZIP and safely repack ZIP archives', 'zip'],
    ['Office Tools', 'file-text', 'DOCX, XLSX, PPTX to PDF (when LibreOffice is available)', 'office'],
];
$operations = [
    'image_compress' => 'Compress image (JPG / PNG / WebP)',
    'image_convert' => 'Convert image to JPG / PNG / WebP',
    'image_resize' => 'Resize image (preserve aspect ratio)',
    'zip_create' => 'Create ZIP (upload multiple files)',
    'zip_extract' => 'Repack safe files from ZIP',
    'pdf_compress' => 'Compress PDF (requires Ghostscript)',
    'pdf_merge' => 'Merge PDFs (requires qpdf)',
    'office_pdf' => 'Office to PDF (requires LibreOffice)',
];
$enabledOperations = array_filter($operations, fn($label, $key) => tool_is_enabled($key), ARRAY_FILTER_USE_BOTH);
$settings = app_settings();
include __DIR__ . '/includes/header.php';
?>
<main class="container">
 <section class="hero"><span class="eyebrow" data-i18n="free">100% Free • No paid API</span><h1 data-i18n="hero">Convert. Compress. Done.</h1><p data-i18n="sub">Your simple all-in-one file converter. Files are temporary and automatically deleted.</p><a class="btn primary" href="#tools" data-i18n="explore">Explore tools</a></section>
 <?php if (!empty($settings['announcement'])): ?><div class="alert announcement"><?=e($settings['announcement'])?></div><?php endif; ?>
 <section id="tools"><div class="section-head"><h2 data-i18n="tools">Choose a tool</h2><span class="muted">PDF · Images · ZIP · Office</span></div>
 <div class="cards">
 <?php foreach ($tools as $t): ?><article class="card"><div class="tool-icon"><i class="fa-solid fa-<?=e($t[1])?>"></i></div><h3><?=e($t[0])?></h3><p><?=e($t[2])?></p><a class="text-link" href="tools.php?category=<?=urlencode($t[3])?>">Open tools →</a></article><?php endforeach; ?>
 </div></section>
 <section class="upload-panel"><h2 data-i18n="quick">Quick file processing</h2><p class="muted">Choose an operation and upload your file. Maximum upload size: <?= (int)max_upload_mb() ?> MB per file, up to <?= (int)config('MAX_FILES_PER_JOB') ?> files.</p>
 <?php if (empty($enabledOperations)): ?><p class="alert error">All processing tools are currently disabled. Please check again later.</p><?php else: ?>
 <form action="process.php" method="post" enctype="multipart/form-data" class="process-form">
 <?=csrf_field()?>
 <label>Operation<select name="operation" id="operationSelect" required>
 <?php foreach ($enabledOperations as $key => $label): ?><option value="<?=e($key)?>"><?=e($label)?></option><?php endforeach; ?>
 </select></label>
 <label>Files<input type="file" name="files[]" id="fileInput" multiple required></label>
 <label>Output format<select name="format"><option value="jpg">JPG</option><option value="png">PNG</option><option value="webp">WebP</option></select></label>
 <label>Image quality <input type="range" name="quality" min="20" max="95" value="75" oninput="this.nextElementSibling.textContent=this.value+'%'"><output>75%</output></label>
 <div id="resizeFields" class="resize-fields" hidden><label>Maximum width (px)<input type="number" name="resize_width" min="1" max="8000" value="1200"></label><label>Maximum height (px)<input type="number" name="resize_height" min="1" max="8000" value="1200"></label><p class="small muted">The image keeps its original proportions and is fitted inside these dimensions.</p></div>
 <button class="btn primary" type="submit">Process files</button>
 </form><?php endif; ?>
 <p class="small muted">PDF and Office operations require additional server software. Availability depends on your hosting plan. Uploaded files are temporary and automatically deleted after <?= (int)config('RETENTION_MINUTES') ?> minutes.</p></section>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
