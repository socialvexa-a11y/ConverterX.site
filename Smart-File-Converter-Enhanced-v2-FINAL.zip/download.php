<?php
require __DIR__.'/includes/bootstrap.php';
$r=$_SESSION['last_result']??null;
if(!$r || time()-($r['created']??0)>(int)config('RETENTION_MINUTES')*60) { http_response_code(404); exit('Download expired.'); }
result_download(SFC_STORAGE.'/processed/'.$r['path'],$r['name']);