<?php
require __DIR__.'/includes/bootstrap.php';
$r=$_SESSION['last_result']??null;
if(!$r || time()-($r['created']??0)>(int)config('RETENTION_MINUTES')*60) { unset($_SESSION['last_result']); flash('Your result expired. Please process the file again.','error'); redirect('index.php'); }
$pageTitle='Your file is ready';
include __DIR__.'/includes/header.php';
$percent=($r['original']??0)>0?max(0,round((1-$r['size']/$r['original'])*100,1)):0;
?>
<main class="container narrow"><section class="result-card"><div class="success-icon"><i class="fa-solid fa-check"></i></div><h1>File processed</h1><p class="muted">Your output is ready to download. It will be deleted automatically after <?= (int)config('RETENTION_MINUTES') ?> minutes.</p>
<div class="stats"><div><span>Original size</span><strong><?=number_format(($r['original']??0)/1048576,2)?> MB</strong></div><div><span>Output size</span><strong><?=number_format($r['size']/1048576,2)?> MB</strong></div><div><span>Size change</span><strong><?=$percent?>%</strong></div></div>
<a class="btn primary" href="download.php"><i class="fa-solid fa-download"></i> Download file</a><a class="btn secondary" href="index.php">Convert another file</a></section></main>
<?php include __DIR__.'/includes/footer.php'; ?>