<?php
return [
    'APP_NAME' => 'Smart File Converter',
    'MAX_UPLOAD_MB' => 50,
    'MAX_FILES_PER_JOB' => 20,
    'MAX_TOTAL_UPLOAD_MB' => 100,
    'MAX_IMAGE_PIXELS' => 12000000,
    'MAX_ZIP_FILES' => 150,
    'MAX_ZIP_UNCOMPRESSED_MB' => 100,
    'RETENTION_MINUTES' => 30,
    'ADMIN_USERNAME' => getenv('SFC_ADMIN_USER') ?: 'admin',
    // Set SFC_ADMIN_PASSWORD_HASH in hosting environment. Never put a plain password here.
    'ADMIN_PASSWORD_HASH' => getenv('SFC_ADMIN_PASSWORD_HASH') ?: '',
    'TIMEZONE' => 'Asia/Kolkata',
];
